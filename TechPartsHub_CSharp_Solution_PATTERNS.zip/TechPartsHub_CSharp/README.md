# TechParts Hub — Refactor a C# (SOLID / por módulos)

Este repositorio es una migración completa del proyecto TechParts Hub desde un script monolítico en Python (Tkinter) a una solución en C# con estructura profesional por carpetas/proyectos.

## Funcionalidad conservada
- Registrar repuestos (stock=0 permitido como “SIN DISPONIBILIDAD”; stock negativo prohibido).
- Listar inventario.
- Buscar repuestos (nombre, código, categoría, fabricante).
- Ordenar inventario (nombre, precio, cantidad; asc/desc).
- Obtener los K repuestos con menor stock.
- Crear pedidos por cliente (si no existe, se crea).
- Agregar ítems validando stock (considera lo ya agregado del mismo repuesto).
- Enviar pedido a cola (no permite pedido vacío o duplicado).
- Ver cola.
- Procesar pedido:
  - Revalida stock antes de descontar.
  - Cancela si el repuesto no existe o si no hay stock.
  - Procesa y descuenta stock si todo OK.
- Ver pedidos con detalle.
- Generar factura simple (separada de Pedido) con un PricingService extensible.

## Cambios para corregir la retroalimentación del profesor
- Separación del negocio en Inventario, Pedidos y Facturación (servicios de aplicación).
- Las “acciones” (buscar/ordenar/etc.) pasan a ser métodos/estrategias (Strategy/Specification), no entidades del dominio.
- El cálculo financiero (totales/descuentos) está separado con PricingService + DiscountPolicy (OCP):
  - `Pedido` ya no calcula subtotales (SRP).
  - El resumen (subtotal/descuento/total) y la factura viven en `FacturacionService`.
- Se mantiene State para estados del pedido.

## Estructura
- `TechPartsHub.Domain`: entidades y reglas de negocio.
- `TechPartsHub.Application`: puertos + servicios del negocio + estrategias/especificaciones + pricing.
- `TechPartsHub.Infrastructure`: implementaciones en memoria (repositorios y cola).
- `TechPartsHub.ConsoleApp`: menú por consola (UI desacoplada).

## Requisitos
- .NET SDK 8 (o compatible con net8.0)

## Ejecutar
```bash
dotnet run --project src/TechPartsHub.ConsoleApp
```

using TechPartsHub.Domain.Inventario;

namespace TechPartsHub.Application.Ports;

public interface IRepositorioRepuesto
{
    void Agregar(Repuesto repuesto);
    void Actualizar(Repuesto repuesto);
    Repuesto? BuscarPorCodigo(string codigo);
    IReadOnlyList<Repuesto> Listar();
}

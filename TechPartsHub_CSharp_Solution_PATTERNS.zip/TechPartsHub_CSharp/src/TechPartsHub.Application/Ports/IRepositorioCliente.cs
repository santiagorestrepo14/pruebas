using TechPartsHub.Domain.Clientes;

namespace TechPartsHub.Application.Ports;

public interface IRepositorioCliente
{
    Cliente? ObtenerPorNombre(string nombre);
    Cliente? BuscarPorId(string id);
    void Guardar(Cliente cliente);
}

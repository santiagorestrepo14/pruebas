namespace TechPartsHub.Application.Ports;

public interface IColaPedido
{
    void Encolar(string pedidoId);
    string? Descolar();
    bool Contiene(string pedidoId);
    IReadOnlyList<string> Listar();
}

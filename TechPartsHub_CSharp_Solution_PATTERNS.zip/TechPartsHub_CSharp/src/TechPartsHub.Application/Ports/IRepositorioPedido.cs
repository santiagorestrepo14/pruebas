using TechPartsHub.Domain.Pedidos;

namespace TechPartsHub.Application.Ports;

public interface IRepositorioPedido
{
    void Guardar(Pedido pedido);
    Pedido? BuscarPorId(string id);
    IReadOnlyList<Pedido> Listar();
}

using TechPartsHub.Domain.Common;
using TechPartsHub.Domain.Pedidos;

namespace TechPartsHub.Application.Pricing;

public sealed class DefaultPricingService : IPricingService
{
    private readonly IDiscountPolicy _discountPolicy;

    public DefaultPricingService(IDiscountPolicy discountPolicy)
        => _discountPolicy = discountPolicy ?? throw new ValidationException("DiscountPolicy es obligatoria.");

    public PricingBreakdown Calcular(Pedido pedido)
    {
        if (pedido is null) throw new ValidationException("El pedido es obligatorio.");

        // El pedido solo administra sus ítems/estado (SRP). El subtotal lo calcula el módulo de pricing.
        var subtotal = pedido.Items.Sum(i => i.Subtotal());
        var descuento = _discountPolicy.CalcularDescuento(pedido, subtotal);

        if (descuento < 0) descuento = 0;
        if (descuento > subtotal) descuento = subtotal;

        return new PricingBreakdown(subtotal, descuento, subtotal - descuento);
    }
}

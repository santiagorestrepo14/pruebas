namespace TechPartsHub.Application.Pricing;

public sealed record PricingBreakdown(decimal Subtotal, decimal Descuento, decimal Total);

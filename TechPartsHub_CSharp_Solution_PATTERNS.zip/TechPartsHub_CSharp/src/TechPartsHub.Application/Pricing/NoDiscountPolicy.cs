using TechPartsHub.Domain.Pedidos;

namespace TechPartsHub.Application.Pricing;

public sealed class NoDiscountPolicy : IDiscountPolicy
{
    public decimal CalcularDescuento(Pedido pedido, decimal subtotal) => 0m;
}

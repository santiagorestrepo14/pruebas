using TechPartsHub.Domain.Pedidos;

namespace TechPartsHub.Application.Pricing;

public interface IDiscountPolicy
{
    decimal CalcularDescuento(Pedido pedido, decimal subtotal);
}

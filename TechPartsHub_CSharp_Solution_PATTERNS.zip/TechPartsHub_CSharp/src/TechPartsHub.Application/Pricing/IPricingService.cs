using TechPartsHub.Domain.Pedidos;

namespace TechPartsHub.Application.Pricing;

public interface IPricingService
{
    PricingBreakdown Calcular(Pedido pedido);
}

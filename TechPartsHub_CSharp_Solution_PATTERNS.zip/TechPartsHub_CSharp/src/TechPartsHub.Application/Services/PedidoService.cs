using TechPartsHub.Application.Ports;
using TechPartsHub.Domain.Clientes;
using TechPartsHub.Domain.Common;
using TechPartsHub.Domain.Pedidos;

namespace TechPartsHub.Application.Services;

public sealed class PedidoService
{
    private readonly IRepositorioCliente _repoCliente;
    private readonly IRepositorioPedido _repoPedido;
    private readonly IRepositorioRepuesto _repoRepuesto;
    private readonly IColaPedido _cola;

    public PedidoService(
        IRepositorioCliente repoCliente,
        IRepositorioPedido repoPedido,
        IRepositorioRepuesto repoRepuesto,
        IColaPedido cola)
    {
        _repoCliente = repoCliente ?? throw new ValidationException("Repositorio de clientes es obligatorio.");
        _repoPedido = repoPedido ?? throw new ValidationException("Repositorio de pedidos es obligatorio.");
        _repoRepuesto = repoRepuesto ?? throw new ValidationException("Repositorio de repuestos es obligatorio.");
        _cola = cola ?? throw new ValidationException("Cola de pedidos es obligatoria.");
    }

    public Pedido CrearPedido(string nombreCliente)
    {
        var nombre = (nombreCliente ?? string.Empty).Trim();
        if (string.IsNullOrWhiteSpace(nombre))
            throw new ValidationException("Ingrese el nombre del cliente.");

        var cliente = _repoCliente.ObtenerPorNombre(nombre);
        if (cliente is null)
        {
            cliente = new Cliente(nombre);
            _repoCliente.Guardar(cliente);
        }

        var pedido = new Pedido(cliente);
        _repoPedido.Guardar(pedido);
        return pedido;
    }

    public void AgregarItem(string pedidoId, string codigoRepuesto, int cantidad)
    {
        var pid = (pedidoId ?? string.Empty).Trim().ToUpperInvariant();
        var cod = (codigoRepuesto ?? string.Empty).Trim().ToUpperInvariant();
        if (string.IsNullOrWhiteSpace(pid))
            throw new ValidationException("El ID del pedido no puede estar vacío.");
        if (string.IsNullOrWhiteSpace(cod))
            throw new ValidationException("El código del repuesto no puede estar vacío.");
        if (cantidad <= 0)
            throw new ValidationException("La cantidad debe ser mayor a cero.");

        var pedido = _repoPedido.BuscarPorId(pid) ?? throw new NotFoundException($"No existe un pedido con ID '{pid}'.");
        pedido.AsegurarEstadoPendiente();

        var repuesto = _repoRepuesto.BuscarPorCodigo(cod) ?? throw new NotFoundException($"No existe un repuesto con código '{cod}'.");

        // Validar stock considerando lo ya reservado dentro del pedido.
        var yaReservado = pedido.CantidadReservada(repuesto.Codigo);
        var totalRequerido = yaReservado + cantidad;

        if (totalRequerido > repuesto.Cantidad)
        {
            throw new BusinessRuleException(
                $"Stock insuficiente para '{repuesto.Nombre}'. Disponible: {repuesto.Cantidad}, ya agregado: {yaReservado}, intentas agregar: {cantidad}.");
        }

        pedido.AgregarItem(repuesto.Codigo, repuesto.Nombre, repuesto.Precio, cantidad);
        _repoPedido.Guardar(pedido);
    }

    public void RemoverItem(string pedidoId, string codigoRepuesto)
    {
        var pid = (pedidoId ?? string.Empty).Trim().ToUpperInvariant();
        if (string.IsNullOrWhiteSpace(pid))
            throw new ValidationException("El ID del pedido no puede estar vacío.");

        var pedido = _repoPedido.BuscarPorId(pid) ?? throw new NotFoundException($"No existe un pedido con ID '{pid}'.");
        pedido.RemoverItem(codigoRepuesto);
        _repoPedido.Guardar(pedido);
    }

    public void EnviarPedido(string pedidoId)
    {
        var pid = (pedidoId ?? string.Empty).Trim().ToUpperInvariant();
        if (string.IsNullOrWhiteSpace(pid))
            throw new ValidationException("El ID del pedido es obligatorio.");

        var pedido = _repoPedido.BuscarPorId(pid) ?? throw new NotFoundException($"No existe un pedido con ID '{pid}'.");
        if (pedido.EstaVacio())
            throw new BusinessRuleException("No se puede enviar un pedido vacío.");
        if (_cola.Contiene(pid))
            throw new BusinessRuleException("El pedido ya está en cola.");

        _cola.Encolar(pid);
    }

    public IReadOnlyList<string> VerCola() => _cola.Listar();

    public IReadOnlyList<Pedido> ListarPedidos() => _repoPedido.Listar();

    public Pedido ObtenerPedido(string pedidoId)
    {
        var pid = (pedidoId ?? string.Empty).Trim().ToUpperInvariant();
        if (string.IsNullOrWhiteSpace(pid))
            throw new ValidationException("El ID del pedido es obligatorio.");
        return _repoPedido.BuscarPorId(pid) ?? throw new NotFoundException($"No existe un pedido con ID '{pid}'.");
    }

}

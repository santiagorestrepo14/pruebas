using TechPartsHub.Application.Ports;
using TechPartsHub.Application.Pricing;
using TechPartsHub.Domain.Common;
using TechPartsHub.Domain.Facturacion;

namespace TechPartsHub.Application.Services;

public sealed class FacturacionService
{
    private readonly IRepositorioPedido _repoPedido;
    private readonly IPricingService _pricing;

    public FacturacionService(IRepositorioPedido repoPedido, IPricingService pricing)
    {
        _repoPedido = repoPedido ?? throw new ValidationException("Repositorio de pedidos es obligatorio.");
        _pricing = pricing ?? throw new ValidationException("PricingService es obligatorio.");
    }

    public Factura GenerarFactura(string pedidoId)
    {
        var pid = (pedidoId ?? string.Empty).Trim().ToUpperInvariant();
        if (string.IsNullOrWhiteSpace(pid))
            throw new ValidationException("El ID del pedido es obligatorio.");

        var pedido = _repoPedido.BuscarPorId(pid) ?? throw new NotFoundException($"No existe un pedido con ID '{pid}'.");

        var breakdown = _pricing.Calcular(pedido);
        return new Factura(pedido.Id, pedido.Cliente.Nombre, breakdown.Subtotal, breakdown.Descuento);
    }

    /// <summary>
    /// Calcula un resumen de precios (subtotal/descuento/total) sin crear una factura.
    /// Se mantiene separado del módulo de Pedidos para evitar mezclar responsabilidades (SRP).
    /// </summary>
    public PricingBreakdown CalcularResumen(string pedidoId)
    {
        var pid = (pedidoId ?? string.Empty).Trim().ToUpperInvariant();
        if (string.IsNullOrWhiteSpace(pid))
            throw new ValidationException("El ID del pedido es obligatorio.");

        var pedido = _repoPedido.BuscarPorId(pid) ?? throw new NotFoundException($"No existe un pedido con ID '{pid}'.");
        return _pricing.Calcular(pedido);
    }
}

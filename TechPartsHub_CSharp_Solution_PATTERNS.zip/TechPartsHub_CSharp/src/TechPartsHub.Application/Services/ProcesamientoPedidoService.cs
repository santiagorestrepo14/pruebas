using TechPartsHub.Application.Ports;
using TechPartsHub.Application.Processing;
using TechPartsHub.Application.Processing.Handlers;
using TechPartsHub.Domain.Common;
using TechPartsHub.Domain.Pedidos;

namespace TechPartsHub.Application.Services;

/// <summary>
/// Servicio de aplicación para procesar pedidos en cola.
/// 
/// Aquí aplicamos Chain of Responsibility para separar:
/// - Cargar pedido
/// - Validar estado
/// - Validar ítems
/// - Validar existencia/stock
/// - Descontar stock
/// - Marcar como procesado
/// 
/// Esto responde a la retro del profesor: el "quehacer" del negocio queda
/// claro por servicios y pasos, sin una lógica monolítica.
/// </summary>
public sealed class ProcesamientoPedidoService
{
    private readonly IRepositorioRepuesto _repoRepuesto;
    private readonly IRepositorioPedido _repoPedido;
    private readonly IColaPedido _cola;

    // Inicio de la cadena (CoR)
    private readonly IPedidoProcessingHandler _pipeline;

    public ProcesamientoPedidoService(IRepositorioRepuesto repoRepuesto, IRepositorioPedido repoPedido, IColaPedido cola)
    {
        _repoRepuesto = repoRepuesto ?? throw new ValidationException("Repositorio de repuestos es obligatorio.");
        _repoPedido = repoPedido ?? throw new ValidationException("Repositorio de pedidos es obligatorio.");
        _cola = cola ?? throw new ValidationException("Cola de pedidos es obligatoria.");

        // Construcción de la cadena de responsabilidad.
        // (También puede extraerse a un Factory si luego quieren variantes de pipeline.)
        var cargar = new CargarPedidoHandler();
        cargar
            .SetNext(new ValidarPedidoPendienteHandler())
            .SetNext(new ValidarItemsNoVaciosHandler())
            .SetNext(new ValidarRepuestosYStockHandler())
            .SetNext(new DescontarStockHandler())
            .SetNext(new MarcarProcesadoHandler());

        _pipeline = cargar;
    }

    public Pedido? ProcesarSiguiente()
    {
        var pedidoId = _cola.Descolar();
        if (string.IsNullOrWhiteSpace(pedidoId))
            return null;

        var ctx = new PedidoProcessingContext(pedidoId, _repoPedido, _repoRepuesto);
        _pipeline.Handle(ctx);

        return ctx.Pedido;
    }
}

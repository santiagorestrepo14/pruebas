using TechPartsHub.Application.Inventario.Busqueda;
using TechPartsHub.Application.Inventario.Ordenamiento;
using TechPartsHub.Application.Ports;
using TechPartsHub.Domain.Common;
using TechPartsHub.Domain.Inventario;

namespace TechPartsHub.Application.Services;

/// <summary>
/// Servicio de aplicación (casos de uso) del módulo de Inventario.
/// 
/// - Usa Specification para búsqueda (IEspecificacionRepuesto)
/// - Usa Strategy para ordenamiento (IEstrategiaOrdenamiento)
/// - Depende de un puerto (IRepositorioRepuesto) -> DIP
/// </summary>
public sealed class InventarioService
{
    private readonly IRepositorioRepuesto _repo;

    public InventarioService(IRepositorioRepuesto repo)
        => _repo = repo ?? throw new ValidationException("Repositorio de repuestos es obligatorio.");

    public void Registrar(Repuesto repuesto)
    {
        if (_repo.BuscarPorCodigo(repuesto.Codigo) is not null)
            throw new BusinessRuleException($"Ya existe un repuesto con el código '{repuesto.Codigo}'.");

        _repo.Agregar(repuesto);
    }

    public IReadOnlyList<Repuesto> Listar() => _repo.Listar();

    public IReadOnlyList<Repuesto> Buscar(IEspecificacionRepuesto especificacion, string valor)
    {
        if (especificacion is null)
            throw new ValidationException("La especificación de búsqueda es obligatoria.");

        var v = (valor ?? string.Empty).Trim();
        if (string.IsNullOrWhiteSpace(v)) return Array.Empty<Repuesto>();

        // Specification: el filtro está en el objeto especificación.
        return _repo.Listar().Where(r => especificacion.Cumple(r, v)).ToList();
    }

    public IReadOnlyList<Repuesto> Ordenar(IEstrategiaOrdenamiento estrategia, bool descendente = false)
    {
        if (estrategia is null)
            throw new ValidationException("La estrategia de ordenamiento es obligatoria.");

        var lista = _repo.Listar();

        // Strategy: la clave de orden la define la estrategia.
        return descendente
            ? lista.OrderByDescending(r => estrategia.ObtenerClave(r)).ToList()
            : lista.OrderBy(r => estrategia.ObtenerClave(r)).ToList();
    }

    public IReadOnlyList<Repuesto> SeleccionarKMenores(int k)
    {
        if (k <= 0) throw new ValidationException("El valor de k debe ser mayor a cero.");

        var lista = _repo.Listar();
        if (lista.Count == 0) throw new BusinessRuleException("El inventario está vacío.");

        // Regla: obtener los k con menor stock.
        return lista.OrderBy(r => r.Cantidad).Take(Math.Min(k, lista.Count)).ToList();
    }
}

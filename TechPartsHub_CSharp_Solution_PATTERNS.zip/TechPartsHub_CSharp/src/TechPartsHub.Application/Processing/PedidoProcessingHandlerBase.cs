namespace TechPartsHub.Application.Processing;

/// <summary>
/// Implementación base del CoR: almacena el siguiente handler y lo invoca
/// si el contexto no está terminado.
/// </summary>
public abstract class PedidoProcessingHandlerBase : IPedidoProcessingHandler
{
    private IPedidoProcessingHandler? _next;

    public IPedidoProcessingHandler SetNext(IPedidoProcessingHandler next)
    {
        _next = next;
        return next;
    }

    public void Handle(PedidoProcessingContext context)
    {
        if (context.Terminada) return;

        HandleInternal(context);

        if (context.Terminada) return;
        _next?.Handle(context);
    }

    protected abstract void HandleInternal(PedidoProcessingContext context);
}

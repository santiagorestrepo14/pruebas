using TechPartsHub.Application.Ports;
using TechPartsHub.Domain.Pedidos;

namespace TechPartsHub.Application.Processing;

/// <summary>
/// Contexto compartido por la cadena de procesamiento (Chain of Responsibility).
/// Permite que cada paso valide y/o aplique cambios sin acoplar toda la lógica
/// en un único método gigante.
/// </summary>
public sealed class PedidoProcessingContext
{
    public string PedidoId { get; }

    public Pedido? Pedido { get; internal set; }

    internal IRepositorioPedido RepoPedido { get; }
    internal IRepositorioRepuesto RepoRepuesto { get; }

    public bool Terminada { get; private set; }

    public PedidoProcessingContext(string pedidoId, IRepositorioPedido repoPedido, IRepositorioRepuesto repoRepuesto)
    {
        PedidoId = pedidoId;
        RepoPedido = repoPedido;
        RepoRepuesto = repoRepuesto;
    }

    public void Terminar() => Terminada = true;
}

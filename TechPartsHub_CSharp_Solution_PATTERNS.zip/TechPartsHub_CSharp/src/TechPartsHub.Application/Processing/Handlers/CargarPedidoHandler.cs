using TechPartsHub.Domain.Pedidos;

namespace TechPartsHub.Application.Processing.Handlers;

/// <summary>
/// Paso 1: carga el pedido desde el repositorio.
/// Si no existe, termina la cadena (no hay nada que procesar).
/// </summary>
public sealed class CargarPedidoHandler : PedidoProcessingHandlerBase
{
    protected override void HandleInternal(PedidoProcessingContext context)
    {
        var pedido = context.RepoPedido.BuscarPorId(context.PedidoId);
        context.Pedido = pedido;

        if (pedido is null)
            context.Terminar();
    }
}

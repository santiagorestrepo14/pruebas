using TechPartsHub.Domain.Pedidos.Estados;

namespace TechPartsHub.Application.Processing.Handlers;

/// <summary>
/// Paso 6: marca el pedido como procesado y lo guarda.
/// </summary>
public sealed class MarcarProcesadoHandler : PedidoProcessingHandlerBase
{
    protected override void HandleInternal(PedidoProcessingContext context)
    {
        var pedido = context.Pedido;
        if (pedido is null) { context.Terminar(); return; }

        pedido.CambiarEstado(new EstadoProcesado());
        context.RepoPedido.Guardar(pedido);
    }
}

namespace TechPartsHub.Application.Processing.Handlers;

/// <summary>
/// Paso 5: descuenta stock y persiste inventario.
/// Se ejecuta solo si la validación previa fue exitosa.
/// </summary>
public sealed class DescontarStockHandler : PedidoProcessingHandlerBase
{
    protected override void HandleInternal(PedidoProcessingContext context)
    {
        var pedido = context.Pedido;
        if (pedido is null) { context.Terminar(); return; }

        foreach (var item in pedido.Items)
        {
            var repuesto = context.RepoRepuesto.BuscarPorCodigo(item.CodigoRepuesto)!;
            repuesto.DescontarStock(item.Cantidad);
            context.RepoRepuesto.Actualizar(repuesto);
        }
    }
}

using TechPartsHub.Domain.Pedidos.Estados;

namespace TechPartsHub.Application.Processing.Handlers;

/// <summary>
/// Paso 2: valida que el pedido esté en estado "Pendiente".
/// Esto aplica el patrón State: el comportamiento permitido depende del estado.
/// </summary>
public sealed class ValidarPedidoPendienteHandler : PedidoProcessingHandlerBase
{
    protected override void HandleInternal(PedidoProcessingContext context)
    {
        var pedido = context.Pedido;
        if (pedido is null) { context.Terminar(); return; }

        // Si no está pendiente, no lo procesamos de nuevo.
        if (pedido.Estado is not EstadoPendiente)
            context.Terminar();
    }
}

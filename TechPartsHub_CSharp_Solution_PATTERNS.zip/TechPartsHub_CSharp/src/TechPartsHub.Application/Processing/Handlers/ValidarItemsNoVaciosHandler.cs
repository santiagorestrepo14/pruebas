using TechPartsHub.Domain.Pedidos.Estados;

namespace TechPartsHub.Application.Processing.Handlers;

/// <summary>
/// Paso 3: un pedido sin ítems no se puede procesar.
/// Si está vacío, se cancela con razón y se guarda.
/// </summary>
public sealed class ValidarItemsNoVaciosHandler : PedidoProcessingHandlerBase
{
    protected override void HandleInternal(PedidoProcessingContext context)
    {
        var pedido = context.Pedido;
        if (pedido is null) { context.Terminar(); return; }

        if (!pedido.Items.Any())
        {
            pedido.CambiarEstado(new EstadoCancelado("No se puede procesar un pedido vacío."));
            context.RepoPedido.Guardar(pedido);
            context.Terminar();
        }
    }
}

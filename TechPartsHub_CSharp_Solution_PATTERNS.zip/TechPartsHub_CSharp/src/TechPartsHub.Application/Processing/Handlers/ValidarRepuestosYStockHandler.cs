using TechPartsHub.Domain.Pedidos.Estados;

namespace TechPartsHub.Application.Processing.Handlers;

/// <summary>
/// Paso 4: valida existencia de repuestos y stock suficiente para TODO el pedido.
/// Importante: aquí NO se descuenta nada; primero validamos todo y luego,
/// en otro handler, aplicamos cambios (evitamos descuentos parciales).
/// </summary>
public sealed class ValidarRepuestosYStockHandler : PedidoProcessingHandlerBase
{
    protected override void HandleInternal(PedidoProcessingContext context)
    {
        var pedido = context.Pedido;
        if (pedido is null) { context.Terminar(); return; }

        foreach (var item in pedido.Items)
        {
            var repuesto = context.RepoRepuesto.BuscarPorCodigo(item.CodigoRepuesto);
            if (repuesto is null)
            {
                pedido.CambiarEstado(new EstadoCancelado("El repuesto ya no existe en inventario."));
                context.RepoPedido.Guardar(pedido);
                context.Terminar();
                return;
            }

            if (item.Cantidad > repuesto.Cantidad)
            {
                pedido.CambiarEstado(new EstadoCancelado(
                    $"Stock insuficiente para {repuesto.Codigo}. Necesita {item.Cantidad}, hay {repuesto.Cantidad}."));
                context.RepoPedido.Guardar(pedido);
                context.Terminar();
                return;
            }
        }
    }
}

namespace TechPartsHub.Application.Processing;

/// <summary>
/// Interfaz base de la cadena de responsabilidad (CoR).
/// Cada handler decide si continúa con el siguiente o detiene la cadena.
/// </summary>
public interface IPedidoProcessingHandler
{
    IPedidoProcessingHandler SetNext(IPedidoProcessingHandler next);
    void Handle(PedidoProcessingContext context);
}

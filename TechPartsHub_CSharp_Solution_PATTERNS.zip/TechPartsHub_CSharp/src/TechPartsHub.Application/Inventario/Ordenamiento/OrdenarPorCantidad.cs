using TechPartsHub.Domain.Inventario;

namespace TechPartsHub.Application.Inventario.Ordenamiento;

public sealed class OrdenarPorCantidad : IEstrategiaOrdenamiento
{
    public string Etiqueta => "Cantidad";
    public IComparable ObtenerClave(Repuesto repuesto) => repuesto.Cantidad;
}

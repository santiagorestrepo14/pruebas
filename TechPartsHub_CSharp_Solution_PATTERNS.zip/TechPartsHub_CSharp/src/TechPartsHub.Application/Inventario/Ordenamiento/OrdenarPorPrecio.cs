using TechPartsHub.Domain.Inventario;

namespace TechPartsHub.Application.Inventario.Ordenamiento;

public sealed class OrdenarPorPrecio : IEstrategiaOrdenamiento
{
    public string Etiqueta => "Precio";
    public IComparable ObtenerClave(Repuesto repuesto) => repuesto.Precio;
}

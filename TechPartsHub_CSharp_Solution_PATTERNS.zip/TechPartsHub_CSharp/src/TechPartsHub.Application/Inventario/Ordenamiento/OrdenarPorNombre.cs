using TechPartsHub.Domain.Inventario;

namespace TechPartsHub.Application.Inventario.Ordenamiento;

public sealed class OrdenarPorNombre : IEstrategiaOrdenamiento
{
    public string Etiqueta => "Nombre";
    public IComparable ObtenerClave(Repuesto repuesto) => repuesto.Nombre.ToLowerInvariant();
}

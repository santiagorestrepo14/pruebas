using TechPartsHub.Domain.Inventario;

namespace TechPartsHub.Application.Inventario.Ordenamiento;

/// <summary>
/// Patrón Strategy: cada implementación define cómo obtener la "clave" de orden
/// (nombre, precio, cantidad, etc.). InventarioService puede ordenar sin saber
/// cuál criterio concreto se está usando (OCP).
/// </summary>
public interface IEstrategiaOrdenamiento
{
    string Etiqueta { get; }
    IComparable ObtenerClave(Repuesto repuesto);
}

using TechPartsHub.Domain.Inventario;

namespace TechPartsHub.Application.Inventario.Busqueda;

public sealed class EspecificacionNombre : IEspecificacionRepuesto
{
    public string Etiqueta => "Nombre contiene";
    public bool Cumple(Repuesto repuesto, string valor)
        => repuesto.Nombre.Contains(valor, StringComparison.OrdinalIgnoreCase);
}

using TechPartsHub.Domain.Inventario;

namespace TechPartsHub.Application.Inventario.Busqueda;

/// <summary>
/// Patrón Specification: encapsula un criterio de búsqueda como un objeto.
/// Permite combinar/crear nuevos filtros sin tocar InventarioService.
/// </summary>
public interface IEspecificacionRepuesto
{
    bool Cumple(Repuesto repuesto, string valor);
    string Etiqueta { get; }
}

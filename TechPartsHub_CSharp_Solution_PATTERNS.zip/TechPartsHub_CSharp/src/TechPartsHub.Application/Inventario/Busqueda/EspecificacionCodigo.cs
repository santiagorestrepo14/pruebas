using TechPartsHub.Domain.Inventario;

namespace TechPartsHub.Application.Inventario.Busqueda;

public sealed class EspecificacionCodigo : IEspecificacionRepuesto
{
    public string Etiqueta => "Código exacto";
    public bool Cumple(Repuesto repuesto, string valor)
        => string.Equals(repuesto.Codigo, valor.Trim().ToUpperInvariant(), StringComparison.OrdinalIgnoreCase);
}

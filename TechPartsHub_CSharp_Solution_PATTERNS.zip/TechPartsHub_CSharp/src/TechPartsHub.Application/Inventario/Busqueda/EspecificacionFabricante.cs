using TechPartsHub.Domain.Inventario;

namespace TechPartsHub.Application.Inventario.Busqueda;

public sealed class EspecificacionFabricante : IEspecificacionRepuesto
{
    public string Etiqueta => "Fabricante contiene";
    public bool Cumple(Repuesto repuesto, string valor)
        => repuesto.Fabricante.Contains(valor, StringComparison.OrdinalIgnoreCase);
}

using TechPartsHub.Domain.Inventario;

namespace TechPartsHub.Application.Inventario.Busqueda;

public sealed class EspecificacionCategoria : IEspecificacionRepuesto
{
    public string Etiqueta => "Categoría exacta";
    public bool Cumple(Repuesto repuesto, string valor)
        => string.Equals(repuesto.Categoria, valor.Trim(), StringComparison.OrdinalIgnoreCase);
}

using TechPartsHub.Application.Pricing;
using TechPartsHub.Application.Services;
using TechPartsHub.ConsoleApp.Commands;
using TechPartsHub.ConsoleApp.Factories;
using TechPartsHub.ConsoleApp.IO;
using TechPartsHub.Domain.Common;
using TechPartsHub.Domain.Inventario;
using TechPartsHub.Infrastructure.Colas;
using TechPartsHub.Infrastructure.Repositorios;

namespace TechPartsHub.ConsoleApp;

internal static class Program
{
    public static void Main()
    {
        // Composition Root: aquí se cablean dependencias.
        // La UI (ConsoleApp) conoce implementaciones concretas (memoria),
        // mientras que Application depende de interfaces (DIP).
        var repoRepuesto = new RepositorioRepuestoMemoria();
        var repoPedido = new RepositorioPedidoMemoria();
        var repoCliente = new RepositorioClienteMemoria();
        var cola = new ColaPedidoLista();

        var discountPolicy = new NoDiscountPolicy();
        var pricing = new DefaultPricingService(discountPolicy);

        var inventario = new InventarioService(repoRepuesto);
        var pedidos = new PedidoService(repoCliente, repoPedido, repoRepuesto, cola);
        var procesamiento = new ProcesamientoPedidoService(repoRepuesto, repoPedido, cola);
        var facturacion = new FacturacionService(repoPedido, pricing);

        var optionsFactory = new InventarioOptionsFactory();
        var io = new DefaultConsoleIO();

        var ctx = new ConsoleContext(inventario, pedidos, procesamiento, facturacion, optionsFactory, io);

        SeedInventario(ctx);

        // Command Pattern: el menú se arma con objetos comando.
        var commands = CommandFactory.CreateAll();
        var map = commands.ToDictionary(c => c.Key, c => c);

        MenuLoop(ctx, commands, map);
    }

    private static void MenuLoop(ConsoleContext ctx, IReadOnlyList<IConsoleCommand> commands, Dictionary<string, IConsoleCommand> map)
    {
        while (!ctx.ShouldExit)
        {
            ctx.IO.WriteLine();
            ctx.IO.WriteLine("=== TechParts Hub — C# (SOLID / por módulos) ===");

            foreach (var cmd in commands.OrderBy(c => ParseKey(c.Key)))
                ctx.IO.WriteLine($"{cmd.Key}) {cmd.Name}");

            ctx.IO.Write("Opción: ");
            var op = ctx.IO.ReadLine()?.Trim() ?? string.Empty;
            ctx.IO.WriteLine();

            if (!map.TryGetValue(op, out var command))
            {
                ctx.IO.WriteLine("Opción inválida.");
                continue;
            }

            try
            {
                command.Execute(ctx);
            }
            catch (DomainException ex)
            {
                ctx.IO.WriteLine($"[ERROR] {ex.Message}");
            }
            catch (Exception ex)
            {
                ctx.IO.WriteLine($"[ERROR INESPERADO] {ex.Message}");
            }
        }
    }

    private static int ParseKey(string key)
        => int.TryParse(key, out var n) ? n : int.MaxValue;

    private static void SeedInventario(ConsoleContext ctx)
    {
        var seed = new List<Repuesto>
        {
            new Repuesto("SSD 1TB", "SSD1TB", "Unidad de estado sólido", "Kingston", 320000m, 7, "Almacenamiento"),
            new Repuesto("RAM 16GB DDR4", "RAM16", "Memoria DDR4 3200MHz", "Corsair", 210000m, 3, "Memoria"),
            new Repuesto("Fuente 650W", "PSU650", "80+ Bronze", "EVGA", 250000m, 0, "Energía"),
            new Repuesto("Ventilador 120mm", "FAN120", "PWM", "CoolerMaster", 45000m, 15, "Refrigeración")
        };

        foreach (var r in seed)
        {
            try { ctx.Inventario.Registrar(r); } catch { }
        }
    }
}

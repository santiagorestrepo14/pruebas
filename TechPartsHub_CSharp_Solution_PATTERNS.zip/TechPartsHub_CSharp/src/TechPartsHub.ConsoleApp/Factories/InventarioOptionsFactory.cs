using TechPartsHub.Application.Inventario.Busqueda;
using TechPartsHub.Application.Inventario.Ordenamiento;

namespace TechPartsHub.ConsoleApp.Factories;

/// <summary>
/// Simple Factory: centraliza la creación/registro de opciones de Inventario
/// (estrategias de ordenamiento y especificaciones de búsqueda).
/// 
/// Ventaja: la UI no necesita conocer todas las clases concretas dispersas,
/// solo pide la lista de opciones y elige.
/// </summary>
public sealed class InventarioOptionsFactory
{
    public IReadOnlyList<IEstrategiaOrdenamiento> CrearEstrategiasOrdenamiento() => new List<IEstrategiaOrdenamiento>
    {
        new OrdenarPorNombre(),
        new OrdenarPorPrecio(),
        new OrdenarPorCantidad()
    };

    public IReadOnlyList<IEspecificacionRepuesto> CrearEspecificacionesBusqueda() => new List<IEspecificacionRepuesto>
    {
        new EspecificacionNombre(),
        new EspecificacionCodigo(),
        new EspecificacionCategoria(),
        new EspecificacionFabricante()
    };
}

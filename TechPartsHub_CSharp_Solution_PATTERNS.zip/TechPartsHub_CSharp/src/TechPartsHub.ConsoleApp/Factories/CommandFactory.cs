using TechPartsHub.ConsoleApp.Commands;

namespace TechPartsHub.ConsoleApp.Factories;

/// <summary>
/// Simple Factory para construir el menú de Commands.
/// </summary>
public static class CommandFactory
{
    public static IReadOnlyList<IConsoleCommand> CreateAll()
        => new List<IConsoleCommand>
        {
            new RegistrarRepuestoCommand(),
            new ListarInventarioCommand(),
            new BuscarRepuestoCommand(),
            new OrdenarInventarioCommand(),
            new MostrarKMenoresCommand(),
            new CrearPedidoCommand(),
            new AgregarItemPedidoCommand(),
            new RemoverItemPedidoCommand(),
            new EnviarPedidoCommand(),
            new VerColaCommand(),
            new ProcesarSiguientePedidoCommand(),
            new VerPedidosCommand(),
            new GenerarFacturaCommand(),
            new SalirCommand()
        };
}

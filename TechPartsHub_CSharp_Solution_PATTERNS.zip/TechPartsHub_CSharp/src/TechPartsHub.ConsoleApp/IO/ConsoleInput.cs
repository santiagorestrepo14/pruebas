namespace TechPartsHub.ConsoleApp.IO;

/// <summary>
/// Utilidades para lectura robusta desde consola.
/// </summary>
public static class ConsoleInput
{
    public static string ReadRequired(IConsoleIO io, string prompt)
    {
        while (true)
        {
            io.Write(prompt);
            var s = io.ReadLine();
            if (!string.IsNullOrWhiteSpace(s))
                return s.Trim();
            io.WriteLine("Campo obligatorio.");
        }
    }

    public static int ReadInt(IConsoleIO io, string prompt, int min = int.MinValue, int max = int.MaxValue)
    {
        while (true)
        {
            io.Write(prompt);
            var s = io.ReadLine();
            if (int.TryParse(s, out var v) && v >= min && v <= max)
                return v;
            io.WriteLine($"Ingrese un entero válido en el rango [{min}, {max}].");
        }
    }

    public static decimal ReadDecimal(IConsoleIO io, string prompt, decimal min = decimal.MinValue, decimal max = decimal.MaxValue)
    {
        while (true)
        {
            io.Write(prompt);
            var s = io.ReadLine();
            if (decimal.TryParse(s, out var v) && v >= min && v <= max)
                return v;
            io.WriteLine($"Ingrese un número válido en el rango [{min}, {max}].");
        }
    }

    public static bool ReadYesNo(IConsoleIO io, string prompt)
    {
        while (true)
        {
            io.Write(prompt);
            var s = (io.ReadLine() ?? "").Trim().ToLowerInvariant();
            if (s is "s" or "si" or "sí" or "y" or "yes") return true;
            if (s is "n" or "no") return false;
            io.WriteLine("Responde con s/n.");
        }
    }
}

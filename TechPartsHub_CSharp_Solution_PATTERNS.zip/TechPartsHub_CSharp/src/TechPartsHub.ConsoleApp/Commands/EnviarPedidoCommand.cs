using TechPartsHub.ConsoleApp.IO;

namespace TechPartsHub.ConsoleApp.Commands;

public sealed class EnviarPedidoCommand : IConsoleCommand
{
    public string Key => "9";
    public string Name => "Enviar pedido a cola";

    public void Execute(ConsoleContext context)
    {
        var io = context.IO;
        io.WriteLine("== Enviar pedido a cola ==");

        var pid = ConsoleInput.ReadRequired(io, "ID pedido: ");
        context.Pedidos.EnviarPedido(pid);
        io.WriteLine("[OK] Pedido enviado a la cola.");
    }
}

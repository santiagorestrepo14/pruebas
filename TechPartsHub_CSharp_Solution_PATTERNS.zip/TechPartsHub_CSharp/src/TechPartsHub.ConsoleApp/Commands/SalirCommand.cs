namespace TechPartsHub.ConsoleApp.Commands;

public sealed class SalirCommand : IConsoleCommand
{
    public string Key => "0";
    public string Name => "Salir";

    public void Execute(ConsoleContext context)
    {
        context.ShouldExit = true;
    }
}

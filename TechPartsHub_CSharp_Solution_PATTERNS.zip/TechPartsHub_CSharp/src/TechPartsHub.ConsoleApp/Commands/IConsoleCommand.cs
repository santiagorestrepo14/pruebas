namespace TechPartsHub.ConsoleApp.Commands;

/// <summary>
/// Patrón Command: cada opción del menú es un objeto.
/// Beneficio: evita un switch gigante y permite agregar/quitar acciones
/// sin modificar el bucle del menú (OCP en la capa de presentación).
/// </summary>
public interface IConsoleCommand
{
    string Key { get; }
    string Name { get; }
    void Execute(ConsoleContext context);
}

namespace TechPartsHub.ConsoleApp.Commands;

public sealed class ProcesarSiguientePedidoCommand : IConsoleCommand
{
    public string Key => "11";
    public string Name => "Procesar siguiente pedido";

    public void Execute(ConsoleContext context)
    {
        var io = context.IO;
        io.WriteLine("== Procesar siguiente pedido ==");

        var pedido = context.Procesamiento.ProcesarSiguiente();
        if (pedido is null)
        {
            io.WriteLine("No hay pedidos en la cola.");
            return;
        }

        io.WriteLine($"Resultado: {pedido}");
        io.WriteLine(pedido.Estado.Mensaje);
    }
}

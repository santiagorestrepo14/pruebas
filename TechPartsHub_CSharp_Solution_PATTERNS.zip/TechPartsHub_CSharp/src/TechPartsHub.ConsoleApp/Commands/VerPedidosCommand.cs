namespace TechPartsHub.ConsoleApp.Commands;

public sealed class VerPedidosCommand : IConsoleCommand
{
    public string Key => "12";
    public string Name => "Ver todos los pedidos";

    public void Execute(ConsoleContext context)
    {
        var io = context.IO;
        io.WriteLine("== Todos los pedidos ==");

        var pedidos = context.Pedidos.ListarPedidos();
        if (pedidos.Count == 0)
        {
            io.WriteLine("No hay pedidos registrados.");
            return;
        }

        foreach (var p in pedidos)
        {
            var resumen = context.Facturacion.CalcularResumen(p.Id);
            io.WriteLine($"{p} | Subtotal: ${resumen.Subtotal:0.00} | Total: ${resumen.Total:0.00}");
            foreach (var item in p.Items)
                io.WriteLine($"   • {item}");
            io.WriteLine();
        }
    }
}

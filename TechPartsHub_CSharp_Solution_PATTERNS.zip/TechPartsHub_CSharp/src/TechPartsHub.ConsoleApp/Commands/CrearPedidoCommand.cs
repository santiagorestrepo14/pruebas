using TechPartsHub.ConsoleApp.IO;

namespace TechPartsHub.ConsoleApp.Commands;

public sealed class CrearPedidoCommand : IConsoleCommand
{
    public string Key => "6";
    public string Name => "Crear pedido";

    public void Execute(ConsoleContext context)
    {
        var io = context.IO;
        io.WriteLine("== Crear pedido ==");

        var nombreCliente = ConsoleInput.ReadRequired(io, "Nombre cliente: ");
        var pedido = context.Pedidos.CrearPedido(nombreCliente);

        io.WriteLine($"[OK] Pedido creado: {pedido} (ID: {pedido.Id})");
        io.WriteLine("Tip: ahora agrega ítems con la opción 7.");
    }
}

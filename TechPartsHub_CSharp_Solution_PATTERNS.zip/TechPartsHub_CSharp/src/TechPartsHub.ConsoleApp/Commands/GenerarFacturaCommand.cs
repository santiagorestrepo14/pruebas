using TechPartsHub.ConsoleApp.IO;

namespace TechPartsHub.ConsoleApp.Commands;

public sealed class GenerarFacturaCommand : IConsoleCommand
{
    public string Key => "13";
    public string Name => "Generar factura de un pedido";

    public void Execute(ConsoleContext context)
    {
        var io = context.IO;
        io.WriteLine("== Generar factura ==");

        var pid = ConsoleInput.ReadRequired(io, "ID pedido: ");
        var factura = context.Facturacion.GenerarFactura(pid);

        io.WriteLine($"[OK] {factura}");
    }
}

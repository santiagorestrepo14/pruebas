namespace TechPartsHub.ConsoleApp.Commands;

public sealed class VerColaCommand : IConsoleCommand
{
    public string Key => "10";
    public string Name => "Ver cola de pedidos";

    public void Execute(ConsoleContext context)
    {
        var io = context.IO;
        io.WriteLine("== Cola de pedidos ==");

        var ids = context.Pedidos.VerCola();
        if (ids.Count == 0)
        {
            io.WriteLine("La cola está vacía.");
            return;
        }

        io.WriteLine($"{ids.Count} pedido(s) en cola:");
        for (var i = 0; i < ids.Count; i++)
        {
            var id = ids[i];
            try
            {
                var pedido = context.Pedidos.ObtenerPedido(id);
                var resumen = context.Facturacion.CalcularResumen(id);
                io.WriteLine($"{i + 1}. {pedido} | Total: ${resumen.Total:0.00}");
            }
            catch
            {
                io.WriteLine($"{i + 1}. ID: {id}");
            }
        }
    }
}

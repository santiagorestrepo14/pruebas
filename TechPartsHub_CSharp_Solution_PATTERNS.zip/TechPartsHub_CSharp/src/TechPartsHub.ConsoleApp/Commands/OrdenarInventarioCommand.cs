using TechPartsHub.ConsoleApp.IO;

namespace TechPartsHub.ConsoleApp.Commands;

public sealed class OrdenarInventarioCommand : IConsoleCommand
{
    public string Key => "4";
    public string Name => "Ordenar inventario";

    public void Execute(ConsoleContext context)
    {
        var io = context.IO;
        io.WriteLine("== Ordenar inventario ==");

        // Strategy: cada IEstrategiaOrdenamiento encapsula una forma de obtener la clave.
        var estrategias = context.InventarioOptions.CrearEstrategiasOrdenamiento();
        for (var i = 0; i < estrategias.Count; i++)
            io.WriteLine($"{i + 1}) {estrategias[i].Etiqueta}");

        var idx = ConsoleInput.ReadInt(io, "Elegir criterio: ", min: 1, max: estrategias.Count) - 1;
        var desc = ConsoleInput.ReadYesNo(io, "¿Descendente? (s/n): ");

        var ordenados = context.Inventario.Ordenar(estrategias[idx], descendente: desc);

        if (ordenados.Count == 0)
        {
            io.WriteLine("Inventario vacío.");
            return;
        }

        foreach (var r in ordenados)
            io.WriteLine($"- {r}");
    }
}

using TechPartsHub.ConsoleApp.IO;

namespace TechPartsHub.ConsoleApp.Commands;

public sealed class AgregarItemPedidoCommand : IConsoleCommand
{
    public string Key => "7";
    public string Name => "Agregar ítem a pedido";

    public void Execute(ConsoleContext context)
    {
        var io = context.IO;
        io.WriteLine("== Agregar ítem a pedido ==");

        var pid = ConsoleInput.ReadRequired(io, "ID pedido: ");
        var cod = ConsoleInput.ReadRequired(io, "Código repuesto: ");
        var qty = ConsoleInput.ReadInt(io, "Cantidad: ", min: 1);

        // Regla de negocio: no permitir agregar si no hay stock suficiente (validado en PedidoService).
        context.Pedidos.AgregarItem(pid, cod, qty);

        var resumen = context.Facturacion.CalcularResumen(pid);
        io.WriteLine($"[OK] Ítem agregado. Subtotal: ${resumen.Subtotal:0.00} | Total: ${resumen.Total:0.00}");
    }
}

using TechPartsHub.ConsoleApp.IO;

namespace TechPartsHub.ConsoleApp.Commands;

public sealed class RemoverItemPedidoCommand : IConsoleCommand
{
    public string Key => "8";
    public string Name => "Remover ítem de pedido";

    public void Execute(ConsoleContext context)
    {
        var io = context.IO;
        io.WriteLine("== Remover ítem de pedido ==");

        var pid = ConsoleInput.ReadRequired(io, "ID pedido: ");
        var cod = ConsoleInput.ReadRequired(io, "Código repuesto a remover: ");

        context.Pedidos.RemoverItem(pid, cod);

        var resumen = context.Facturacion.CalcularResumen(pid);
        io.WriteLine($"[OK] Ítem removido. Subtotal: ${resumen.Subtotal:0.00} | Total: ${resumen.Total:0.00}");
    }
}

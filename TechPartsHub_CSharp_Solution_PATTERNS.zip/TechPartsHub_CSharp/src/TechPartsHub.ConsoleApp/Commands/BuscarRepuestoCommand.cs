using TechPartsHub.ConsoleApp.IO;

namespace TechPartsHub.ConsoleApp.Commands;

public sealed class BuscarRepuestoCommand : IConsoleCommand
{
    public string Key => "3";
    public string Name => "Buscar repuesto";

    public void Execute(ConsoleContext context)
    {
        var io = context.IO;
        io.WriteLine("== Buscar repuesto ==");

        var especificaciones = context.InventarioOptions.CrearEspecificacionesBusqueda();
        for (var i = 0; i < especificaciones.Count; i++)
            io.WriteLine($"{i + 1}) {especificaciones[i].Etiqueta}");

        var idx = ConsoleInput.ReadInt(io, "Elegir filtro: ", min: 1, max: especificaciones.Count) - 1;

        var valor = ConsoleInput.ReadRequired(io, "Valor a buscar: ");
        var resultados = context.Inventario.Buscar(especificaciones[idx], valor);

        io.WriteLine();
        if (resultados.Count == 0)
        {
            io.WriteLine("No se encontraron resultados.");
            return;
        }

        io.WriteLine($"Resultados ({resultados.Count}):");
        foreach (var r in resultados)
            io.WriteLine($"- {r}");
    }
}

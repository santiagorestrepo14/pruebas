namespace TechPartsHub.ConsoleApp.Commands;

public sealed class ListarInventarioCommand : IConsoleCommand
{
    public string Key => "2";
    public string Name => "Listar inventario";

    public void Execute(ConsoleContext context)
    {
        var io = context.IO;
        io.WriteLine("== Inventario ==");

        var lista = context.Inventario.Listar();
        if (lista.Count == 0)
        {
            io.WriteLine("Inventario vacío.");
            return;
        }

        foreach (var r in lista)
            io.WriteLine($"- {r}");
    }
}

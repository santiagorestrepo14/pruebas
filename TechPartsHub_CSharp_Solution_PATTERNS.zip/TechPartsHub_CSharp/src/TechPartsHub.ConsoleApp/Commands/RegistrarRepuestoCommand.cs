using TechPartsHub.ConsoleApp.IO;
using TechPartsHub.Domain.Inventario;

namespace TechPartsHub.ConsoleApp.Commands;

public sealed class RegistrarRepuestoCommand : IConsoleCommand
{
    public string Key => "1";
    public string Name => "Registrar repuesto";

    public void Execute(ConsoleContext context)
    {
        var io = context.IO;
        io.WriteLine("== Registrar repuesto ==");

        var nombre = ConsoleInput.ReadRequired(io, "Nombre: ");
        var codigo = ConsoleInput.ReadRequired(io, "Código: ");
        io.Write("Descripción (opcional): ");
        var descripcion = io.ReadLine();
        var fabricante = ConsoleInput.ReadRequired(io, "Fabricante: ");
        var categoria = ConsoleInput.ReadRequired(io, "Categoría: ");
        var precio = ConsoleInput.ReadDecimal(io, "Precio (>0): ", min: 0.01m);
        var cantidad = ConsoleInput.ReadInt(io, "Cantidad (>=0): ", min: 0);

        var repuesto = new Repuesto(nombre, codigo, descripcion, fabricante, precio, cantidad, categoria);
        context.Inventario.Registrar(repuesto);

        if (repuesto.Cantidad == 0)
            io.WriteLine($"[OK] Repuesto '{repuesto.Nombre}' registrado SIN DISPONIBILIDAD (stock=0)." );
        else
            io.WriteLine($"[OK] Repuesto '{repuesto.Nombre}' registrado exitosamente.");
    }
}

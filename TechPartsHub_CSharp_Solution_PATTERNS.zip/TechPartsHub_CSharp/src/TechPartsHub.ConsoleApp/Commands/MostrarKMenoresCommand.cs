using TechPartsHub.ConsoleApp.IO;

namespace TechPartsHub.ConsoleApp.Commands;

public sealed class MostrarKMenoresCommand : IConsoleCommand
{
    public string Key => "5";
    public string Name => "Mostrar K repuestos con menor stock";

    public void Execute(ConsoleContext context)
    {
        var io = context.IO;
        io.WriteLine("== K repuestos con menor stock ==");

        var k = ConsoleInput.ReadInt(io, "K: ", min: 1);
        var lista = context.Inventario.SeleccionarKMenores(k);

        io.WriteLine($"Top {lista.Count} repuesto(s) con menor stock:");
        foreach (var r in lista)
            io.WriteLine($"- {r}");
    }
}

using TechPartsHub.Application.Services;
using TechPartsHub.ConsoleApp.Factories;
using TechPartsHub.ConsoleApp.IO;

namespace TechPartsHub.ConsoleApp;

/// <summary>
/// Contexto compartido para Commands.
/// Mantiene los servicios del negocio y utilidades de consola.
/// </summary>
public sealed class ConsoleContext
{
    public InventarioService Inventario { get; }
    public PedidoService Pedidos { get; }
    public ProcesamientoPedidoService Procesamiento { get; }
    public FacturacionService Facturacion { get; }

    public InventarioOptionsFactory InventarioOptions { get; }

    public IConsoleIO IO { get; }

    public bool ShouldExit { get; set; }

    public ConsoleContext(
        InventarioService inventario,
        PedidoService pedidos,
        ProcesamientoPedidoService procesamiento,
        FacturacionService facturacion,
        InventarioOptionsFactory inventarioOptions,
        IConsoleIO io)
    {
        Inventario = inventario;
        Pedidos = pedidos;
        Procesamiento = procesamiento;
        Facturacion = facturacion;
        InventarioOptions = inventarioOptions;
        IO = io;
    }
}

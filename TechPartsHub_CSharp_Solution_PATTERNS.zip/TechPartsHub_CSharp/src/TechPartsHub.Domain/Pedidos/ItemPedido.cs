using TechPartsHub.Domain.Common;

namespace TechPartsHub.Domain.Pedidos;

public sealed class ItemPedido
{
    public string CodigoRepuesto { get; }
    public string NombreRepuestoSnapshot { get; }
    public decimal PrecioUnitarioSnapshot { get; }
    public int Cantidad { get; private set; }

    public ItemPedido(string codigoRepuesto, string nombreRepuesto, decimal precioUnitario, int cantidad)
    {
        if (string.IsNullOrWhiteSpace(codigoRepuesto))
            throw new ValidationException("El código del repuesto no puede estar vacío.");
        if (string.IsNullOrWhiteSpace(nombreRepuesto))
            throw new ValidationException("El nombre del repuesto no puede estar vacío.");
        if (precioUnitario <= 0)
            throw new ValidationException("El precio unitario debe ser mayor a 0.");
        if (cantidad <= 0)
            throw new ValidationException("La cantidad del ítem debe ser mayor a cero.");

        CodigoRepuesto = codigoRepuesto.Trim().ToUpperInvariant();
        NombreRepuestoSnapshot = nombreRepuesto.Trim();
        PrecioUnitarioSnapshot = precioUnitario;
        Cantidad = cantidad;
    }

    public void Incrementar(int cantidad)
    {
        if (cantidad <= 0)
            throw new ValidationException("La cantidad a incrementar debe ser mayor a cero.");
        Cantidad += cantidad;
    }

    public decimal Subtotal() => PrecioUnitarioSnapshot * Cantidad;

    public override string ToString() => $"{NombreRepuestoSnapshot} ({CodigoRepuesto}) x{Cantidad} = ${Subtotal():0.00}";
}

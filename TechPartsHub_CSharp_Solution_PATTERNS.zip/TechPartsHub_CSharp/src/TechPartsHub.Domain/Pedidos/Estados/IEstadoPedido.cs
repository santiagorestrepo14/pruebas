namespace TechPartsHub.Domain.Pedidos.Estados;

/// <summary>
/// Patrón State: el Pedido delega información (y potencialmente comportamiento)
/// al objeto Estado. Así evitamos if/else por estado y podemos agregar nuevos
/// estados sin modificar la clase Pedido (OCP).
/// </summary>
public interface IEstadoPedido
{
    string Nombre { get; }
    string Mensaje { get; }
}

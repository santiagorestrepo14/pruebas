namespace TechPartsHub.Domain.Pedidos.Estados;

public sealed class EstadoPendiente : IEstadoPedido
{
    public string Nombre => "Pendiente";
    public string Mensaje => "El pedido está en espera de ser procesado.";
}

namespace TechPartsHub.Domain.Pedidos.Estados;

public sealed class EstadoProcesado : IEstadoPedido
{
    public string Nombre => "Procesado";
    public string Mensaje => "El pedido ha sido procesado exitosamente (stock descontado).";
}

namespace TechPartsHub.Domain.Pedidos.Estados;

public sealed class EstadoCancelado : IEstadoPedido
{
    public string Razon { get; }

    public EstadoCancelado(string? razon = null)
    {
        Razon = string.IsNullOrWhiteSpace(razon) ? "Sin razón especificada" : razon.Trim();
    }

    public string Nombre => "Cancelado";
    public string Mensaje => $"El pedido fue cancelado. Razón: {Razon}";
}

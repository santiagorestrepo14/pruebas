using TechPartsHub.Domain.Clientes;
using TechPartsHub.Domain.Common;
using TechPartsHub.Domain.Pedidos.Estados;

namespace TechPartsHub.Domain.Pedidos;

/// <summary>
/// Entidad de dominio: Pedido.
/// 
/// SRP (según la retro del profesor):
/// - Pedido se encarga de sus ítems y de su ciclo de vida (estado).
/// - Cálculos financieros (subtotal/total/descuentos) van en Facturación/Pricing,
///   no aquí.
/// 
/// State: el pedido mantiene un IEstadoPedido que representa su situación.
/// </summary>
public sealed class Pedido
{
    private readonly List<ItemPedido> _items = new();

    public string Id { get; }
    public Cliente Cliente { get; }
    public IEstadoPedido Estado { get; private set; }

    public IReadOnlyList<ItemPedido> Items => _items.AsReadOnly();

    public Pedido(Cliente cliente)
    {
        Cliente = cliente ?? throw new ValidationException("El cliente es obligatorio.");
        Id = Guid.NewGuid().ToString("N")[..8].ToUpperInvariant();
        Estado = new EstadoPendiente();
    }

    public void AsegurarEstadoPendiente()
    {
        // State: las operaciones permitidas dependen del estado actual.
        if (Estado.Nombre != "Pendiente")
            throw new BusinessRuleException("Solo se pueden modificar pedidos en estado Pendiente.");
    }

    public int CantidadReservada(string codigoRepuesto)
    {
        if (string.IsNullOrWhiteSpace(codigoRepuesto)) return 0;
        var cod = codigoRepuesto.Trim().ToUpperInvariant();
        return _items.Where(i => i.CodigoRepuesto == cod).Sum(i => i.Cantidad);
    }

    public void AgregarItem(string codigoRepuesto, string nombreRepuesto, decimal precioUnitario, int cantidad)
    {
        AsegurarEstadoPendiente();

        var cod = (codigoRepuesto ?? string.Empty).Trim().ToUpperInvariant();
        if (string.IsNullOrWhiteSpace(cod))
            throw new ValidationException("El código del repuesto no puede estar vacío.");

        // Si ya existe el repuesto en el pedido, agregamos cantidad.
        var existente = _items.FirstOrDefault(i => i.CodigoRepuesto == cod);
        if (existente is null)
        {
            _items.Add(new ItemPedido(cod, nombreRepuesto, precioUnitario, cantidad));
            return;
        }

        existente.Incrementar(cantidad);
    }

    public void RemoverItem(string codigoRepuesto)
    {
        AsegurarEstadoPendiente();

        var cod = (codigoRepuesto ?? string.Empty).Trim().ToUpperInvariant();
        if (string.IsNullOrWhiteSpace(cod))
            throw new ValidationException("El código del repuesto no puede estar vacío.");

        var removed = _items.RemoveAll(i => i.CodigoRepuesto == cod);
        if (removed == 0)
            throw new NotFoundException($"No existe un ítem con código '{cod}' dentro del pedido.");
    }

    public void CambiarEstado(IEstadoPedido estado)
    {
        Estado = estado ?? throw new ValidationException("El estado es obligatorio.");
    }

    public bool EstaVacio() => _items.Count == 0;

    public override string ToString()
        => $"Pedido #{Id} | Cliente: {Cliente.Nombre} | Estado: {Estado.Nombre}";
}

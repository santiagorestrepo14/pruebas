using TechPartsHub.Domain.Common;

namespace TechPartsHub.Domain.Facturacion;

public sealed class Factura
{
    public string Id { get; }
    public string PedidoId { get; }
    public string ClienteNombre { get; }
    public DateTimeOffset Fecha { get; }
    public decimal Subtotal { get; }
    public decimal Descuento { get; }
    public decimal Total { get; }

    public Factura(string pedidoId, string clienteNombre, decimal subtotal, decimal descuento)
    {
        if (string.IsNullOrWhiteSpace(pedidoId))
            throw new ValidationException("El ID del pedido es obligatorio.");
        if (string.IsNullOrWhiteSpace(clienteNombre))
            throw new ValidationException("El nombre del cliente es obligatorio.");
        if (subtotal < 0)
            throw new ValidationException("El subtotal no puede ser negativo.");
        if (descuento < 0)
            throw new ValidationException("El descuento no puede ser negativo.");
        if (descuento > subtotal)
            throw new ValidationException("El descuento no puede ser mayor al subtotal.");

        Id = Guid.NewGuid().ToString("N")[..8].ToUpperInvariant();
        PedidoId = pedidoId.Trim().ToUpperInvariant();
        ClienteNombre = clienteNombre.Trim();
        Fecha = DateTimeOffset.Now;
        Subtotal = subtotal;
        Descuento = descuento;
        Total = subtotal - descuento;
    }

    public override string ToString()
        => $"Factura #{Id} | Pedido: {PedidoId} | Cliente: {ClienteNombre} | Total: ${Total:0.00} ({Fecha:yyyy-MM-dd HH:mm})";
}

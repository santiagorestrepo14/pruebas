using TechPartsHub.Domain.Common;

namespace TechPartsHub.Domain.Inventario;

public sealed class Repuesto
{
    public string Nombre { get; }
    public string Codigo { get; }
    public string Descripcion { get; }
    public string Fabricante { get; }
    public decimal Precio { get; }
    public int Cantidad { get; private set; }
    public string Categoria { get; }

    public Repuesto(
        string nombre,
        string codigo,
        string? descripcion,
        string fabricante,
        decimal precio,
        int cantidad,
        string categoria)
    {
        if (string.IsNullOrWhiteSpace(nombre))
            throw new ValidationException("El nombre no puede estar vacío.");
        if (string.IsNullOrWhiteSpace(codigo))
            throw new ValidationException("El código no puede estar vacío.");
        if (string.IsNullOrWhiteSpace(fabricante))
            throw new ValidationException("El fabricante no puede estar vacío.");
        if (string.IsNullOrWhiteSpace(categoria))
            throw new ValidationException("La categoría no puede estar vacía.");

        if (precio <= 0)
            throw new ValidationException("El precio debe ser mayor a 0.");
        if (cantidad < 0)
            throw new ValidationException("La cantidad (stock) no puede ser negativa.");

        Nombre = nombre.Trim();
        Codigo = codigo.Trim().ToUpperInvariant();
        Descripcion = (descripcion ?? string.Empty).Trim();
        Fabricante = fabricante.Trim();
        Precio = precio;
        Cantidad = cantidad;
        Categoria = categoria.Trim();
    }

    public void DescontarStock(int cantidad)
    {
        if (cantidad <= 0)
            throw new ValidationException("La cantidad a descontar debe ser mayor a cero.");

        if (cantidad > Cantidad)
            throw new BusinessRuleException(
                $"Stock insuficiente para '{Nombre}' ({Codigo}). Disponible: {Cantidad}, requerido: {cantidad}.");

        Cantidad -= cantidad;
    }

    public override string ToString()
    {
        var disponibilidad = Cantidad == 0 ? "SIN DISPONIBILIDAD" : $"Stock: {Cantidad}";
        return $"{Nombre} ({Codigo}) - {Categoria} | {Fabricante} | ${Precio:0.00} | {disponibilidad}";
    }
}

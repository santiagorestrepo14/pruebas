using TechPartsHub.Domain.Common;

namespace TechPartsHub.Domain.Clientes;

public sealed class Cliente
{
    public string Id { get; }
    public string Nombre { get; }

    public Cliente(string nombre)
    {
        if (string.IsNullOrWhiteSpace(nombre))
            throw new ValidationException("El nombre del cliente no puede estar vacío.");

        Id = Guid.NewGuid().ToString("N")[..8].ToUpperInvariant();
        Nombre = nombre.Trim();
    }

    public override string ToString() => $"{Nombre} (ID: {Id})";
}

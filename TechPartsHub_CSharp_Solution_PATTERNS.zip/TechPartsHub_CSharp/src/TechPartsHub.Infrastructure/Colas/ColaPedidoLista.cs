using TechPartsHub.Application.Ports;

namespace TechPartsHub.Infrastructure.Colas;

public sealed class ColaPedidoLista : IColaPedido
{
    private readonly object _lock = new();
    private readonly List<string> _ids = new();

    public void Encolar(string pedidoId)
    {
        if (string.IsNullOrWhiteSpace(pedidoId)) return;
        lock (_lock)
        {
            _ids.Add(pedidoId.Trim().ToUpperInvariant());
        }
    }

    public string? Descolar()
    {
        lock (_lock)
        {
            if (_ids.Count == 0) return null;
            var first = _ids[0];
            _ids.RemoveAt(0);
            return first;
        }
    }

    public bool Contiene(string pedidoId)
    {
        if (string.IsNullOrWhiteSpace(pedidoId)) return false;
        var pid = pedidoId.Trim().ToUpperInvariant();
        lock (_lock)
        {
            return _ids.Contains(pid);
        }
    }

    public IReadOnlyList<string> Listar()
    {
        lock (_lock)
        {
            return _ids.ToList();
        }
    }
}

using System.Collections.Concurrent;
using TechPartsHub.Application.Ports;
using TechPartsHub.Domain.Pedidos;

namespace TechPartsHub.Infrastructure.Repositorios;

public sealed class RepositorioPedidoMemoria : IRepositorioPedido
{
    private readonly ConcurrentDictionary<string, Pedido> _datos = new();

    public void Guardar(Pedido pedido)
        => _datos[pedido.Id] = pedido;

    public Pedido? BuscarPorId(string id)
    {
        if (string.IsNullOrWhiteSpace(id)) return null;
        var key = id.Trim().ToUpperInvariant();
        return _datos.TryGetValue(key, out var p) ? p : null;
    }

    public IReadOnlyList<Pedido> Listar()
        => _datos.Values.OrderByDescending(p => p.Id).ToList();
}

using System.Collections.Concurrent;
using TechPartsHub.Application.Ports;
using TechPartsHub.Domain.Inventario;

namespace TechPartsHub.Infrastructure.Repositorios;

public sealed class RepositorioRepuestoMemoria : IRepositorioRepuesto
{
    private readonly ConcurrentDictionary<string, Repuesto> _datos = new();

    public void Agregar(Repuesto repuesto)
        => _datos[repuesto.Codigo] = repuesto;

    public void Actualizar(Repuesto repuesto)
        => _datos[repuesto.Codigo] = repuesto;

    public Repuesto? BuscarPorCodigo(string codigo)
    {
        if (string.IsNullOrWhiteSpace(codigo)) return null;
        var key = codigo.Trim().ToUpperInvariant();
        return _datos.TryGetValue(key, out var rep) ? rep : null;
    }

    public IReadOnlyList<Repuesto> Listar()
        => _datos.Values.OrderBy(r => r.Codigo).ToList();
}

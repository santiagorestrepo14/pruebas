using System.Collections.Concurrent;
using TechPartsHub.Application.Ports;
using TechPartsHub.Domain.Clientes;

namespace TechPartsHub.Infrastructure.Repositorios;

public sealed class RepositorioClienteMemoria : IRepositorioCliente
{
    private readonly ConcurrentDictionary<string, Cliente> _datos = new();

    public Cliente? ObtenerPorNombre(string nombre)
    {
        if (string.IsNullOrWhiteSpace(nombre)) return null;

        var n = nombre.Trim();
        return _datos.Values.FirstOrDefault(c => string.Equals(c.Nombre, n, StringComparison.OrdinalIgnoreCase));
    }

    public Cliente? BuscarPorId(string id)
    {
        if (string.IsNullOrWhiteSpace(id)) return null;
        var key = id.Trim().ToUpperInvariant();
        return _datos.TryGetValue(key, out var c) ? c : null;
    }

    public void Guardar(Cliente cliente)
        => _datos[cliente.Id] = cliente;
}
